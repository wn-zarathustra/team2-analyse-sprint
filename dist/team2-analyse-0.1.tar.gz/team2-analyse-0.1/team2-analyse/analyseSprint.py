def dictionary_of_metrics(items):

  ### Code Here

  pass

def five_num_summ(items):

  ### Code Here

  pass

def date_parser(list_dates):

  ### Code Here

  pass

def extract_municipality_hashtags(df):

  ### Code Here

  pass

def number_of_tweets_per_day(df):

  ### Code Here

  pass

def word_spliter(df):

  ### Code Here

  pass

def stop_words_http_remover(df):

  # Code Here

  pass